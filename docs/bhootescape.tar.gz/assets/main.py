"""Web entry point for Bhoot Escape (pygbag / WebAssembly build).

pygbag runs this file's ``asyncio.run(main())`` inside the browser event loop.
The actual game lives in ``game.py`` and is shared with the desktop build.
"""
import asyncio

from game import main

asyncio.run(main())
